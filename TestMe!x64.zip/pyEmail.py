import email, smtplib, ssl
import re
import mimetypes
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


# otvetiTestMe2021

fileName = 'User\\UserInfo.txt'

with open(fileName, 'r') as f:
        text = f.readline()
f.close()
#print(text)
name = re.sub(r'\w+\:', '', text)


subject = f"TestMe ответы пользовотеля {name}"
body = f"Это автоматическое письмо с ответами пользовотеля {name}"
#print(body)
sender_email = "otvetitestme@gmail.com"

with open('Tests\\Email.txt', 'r') as f:
        text = f.readline()
f.close()
#print(text)

receiver_email = text
password = "otvetiTestMe2021"


message = MIMEMultipart()
message["From"] = sender_email
message["To"] = receiver_email
message["Subject"] = subject
message["Bcc"] = receiver_email  
 
# Внесение тела письма
message.attach(MIMEText(body, "plain"))

ctype, encoding = mimetypes.guess_type(fileName)
maintype, subtype = ctype.split('/', 1)

#print(maintype)
#print(subtype)

with open(fileName) as attachment:
        #print(1234567890)
        part = MIMEText(attachment.read(), _subtype=subtype)
        attachment.close()
        #part = MIMEBase("application", "octet-stream")
        #part.set_payload(attachment.read())
 
# Шифровка файла под ASCII символы для отправки по почте    
#encoders.encode_base64(part)
 
# Внесение заголовка в виде пара/ключ к части вложения

part.add_header(
        "Content-Disposition",
        "attachment",
        filename = "Ответы.txt"
        )



# Внесение вложения в сообщение и конвертация сообщения в строку
message.attach(part)
text = message.as_string()
 
# Подключение к серверу при помощи безопасного контекста и отправка письма
context = ssl.create_default_context()
with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, text)


